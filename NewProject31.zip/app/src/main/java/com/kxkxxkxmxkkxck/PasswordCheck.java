package com.kxkxxkxmxkkxck;

import android.app.Activity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

public class PasswordCheck {

    private Activity activity;

    public PasswordCheck(Activity activity) {
        this.activity = activity;
    }

    public void setupPasswordCheck(final View bannerView) {
        final EditText editTextPassword = bannerView.findViewById(R.id.editText1);
        Button buttonCheck = bannerView.findViewById(R.id.button1);

        buttonCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputPassword = editTextPassword.getText().toString();
                if ("588890".equals(inputPassword)) {
                    // Скрыть окно
                    WindowManager windowManager = (WindowManager) activity.getSystemService(Activity.WINDOW_SERVICE);
                    windowManager.removeView(bannerView);
                } else {
                    // Показать сообщение об ошибке
                    editTextPassword.setText("CÓDIGO INCORRETO");
                }
            }
        });
    }
}